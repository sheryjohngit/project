<?php 
include('config.php');
include('header.php');
?>

<?php
include('footer.php');
?>