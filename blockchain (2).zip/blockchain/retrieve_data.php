<?php 
include('config.php');
include('header.php');
?>
    <h1 class="h3 mb-4 text-gray-800">Retrieve data from Blockchain</h1>
<?php
include('footer.php');
?>