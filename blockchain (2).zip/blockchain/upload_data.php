<?php
include('config.php');

// Function to handle file upload
function handleFileUpload($fileKey, $targetDir, $allowedExtensions) {
    $uploadOk = 1;
    $target_file = $targetDir . basename($_FILES[$fileKey]["name"]);
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if file already exists
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.<br>";
        $uploadOk = 0;
    }

    // Check file size (adjust as per your requirement)
    if ($_FILES[$fileKey]["size"] > 5000000) {
        echo "Sorry, your file is too large.<br>";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if (!in_array($fileType, $allowedExtensions)) {
        echo "Sorry, only " . implode(", ", $allowedExtensions) . " files are allowed.<br>";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.<br>";
    } else {
        // Try to upload the file
        if (move_uploaded_file($_FILES[$fileKey]["tmp_name"], $target_file)) {
            echo "The file " . htmlspecialchars(basename($_FILES[$fileKey]["name"])) . " has been uploaded.<br>";
            return $target_file;
        } else {
            echo "Sorry, there was an error uploading your file.<br>";
        }
    }
    return null;
}

// Handle the form submission for image upload
if (isset($_POST["submit"])) {
    $target_dir = "uploads/";

    // Check if the directory exists, if not create it
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Handle image upload
    if ($_FILES["fileToUpload"]["name"] != '') {
        $imageExtensions = ["jpg", "jpeg", "png", "gif", "dcm"];
        handleFileUpload("fileToUpload", $target_dir, $imageExtensions);
    }
}

// Handle the form submission for CSV upload
if (isset($_POST["submit_csv"])) {
    $target_dir = "uploads/csv/";

    // Check if the directory exists, if not create it
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Handle CSV upload
    if ($_FILES["fileToUploadCSV"]["name"] != '') {
        $csvExtensions = ["csv"];
        $uploadedCSVFile = handleFileUpload("fileToUploadCSV", $target_dir, $csvExtensions);

        // Process the uploaded CSV file
        if ($uploadedCSVFile !== null && ($handle = fopen($uploadedCSVFile, "r")) !== FALSE) {
            echo "<h2>Uploaded CSV Data:</h2>";
            echo "<table border='1'>";
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                echo "<tr>";
                foreach ($data as $value) {
                    echo "<td>$value</td>";
                }
                echo "</tr>";
            }
            fclose($handle);
            echo "</table>";
        } else {
            echo "Error opening uploaded CSV file.";
        }
    }
}

include('header.php');
?>

<h1 class="h3 mb-4 text-gray-800">Upload Data</h1>

<!-- HTML Form for Image Upload -->
<form action="upload_data.php" method="post" enctype="multipart/form-data">
    <h3>Upload Image:</h3>
    <input type="file" name="fileToUpload" id="fileToUpload" accept="image/*">
    <input type="submit" value="Upload Image" name="submit">
</form>

<hr>

<!-- HTML Form for CSV Upload -->
<form action="upload_data.php" method="post" enctype="multipart/form-data">
    <h3>Upload CSV:</h3>
    <input type="file" name="fileToUploadCSV" id="fileToUploadCSV" accept=".csv">
    <input type="submit" value="Upload CSV" name="submit_csv">
</form>

<?php
require_once 'config.php';
$sql = "SELECT * FROM dataset";

//echo $sql;        
$result = $conn->query($sql);
$sno = 0;
while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    if (isset($_REQUEST['save'])) { 
        echo "<td>" . ++$sno . "</td>";
        echo "<td>" . $row['profileid'] . "</td>";
        echo "<td>" . $row['patientid'] . "</td>";
        echo "<td>" . $row['age'] . "</td>";
        echo "<td>" . $row['gender'] . "</td>";
        echo "<td>" . $row['height'] . "</td>";
        echo "<td>" . $row['weight'] . "</td>";
        echo "<td>" . $row['ap_hi'] . "</td>";
        echo "<td>" . $row['ap_lo'] . "</td>";
        echo "<td>" . $row['cholesterol'] . "</td>";
        echo "<td>" . $row['gluc'] . "</td>";
        echo "<td>" . $row['smoke'] . "</td>";
        echo "<td>" . $row['alcho'] . "</td>";
        echo "<td>" . $row['active'] . "</td>";
        echo "<td>" . $row['cardio'] . "</td>";
    } else {
        echo "<td>" . ++$sno . "</td>";
        echo "<td>" . $row['profileid'] . "</td>";
        echo "<td>" . $row['patientid'] . "</td>";
        echo "<td>" . $row['age'] . "</td>";
        echo "<td>" . $row['gender'] . "</td>";
        echo "<td>" . $row['height'] . "</td>";
        echo "<td>" . $row['weight'] . "</td>";
        echo "<td>" . $row['ap_hi'] . "</td>";
        echo "<td>" . $row['ap_lo'] . "</td>";
        echo "<td>" . $row['cholesterol'] . "</td>";
        echo "<td>" . $row['gluc'] . "</td>";
        echo "<td>" . $row['smoke'] . "</td>";
        echo "<td>" . $row['alcho'] . "</td>";
        echo "<td>" . $row['active'] . "</td>";
        echo "<td>" . $row['cardio'] . "</td>";
        echo "<td><a href='uploads/" . $row['fpath'] . "'>Download</a></td>";
    }
    echo "</tr>";
}
?>
</tbody>

<?php
include('footer.php');
?>
