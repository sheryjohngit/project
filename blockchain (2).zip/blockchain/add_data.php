<?php 
include('config.php');
include('header.php');
// action varible for using insert update and delete opretion which retrive from query string
$action = "";
if(isset($_REQUEST['action'])){
	$action = $_REQUEST['action'];
}
?>
<!--start of header name-->
 <h1 class="h3 mb-4 text-gray-800">Add Data</h1>
 <!--end of header name-->
        <?php
//Start of insert opretion
if(isset($_REQUEST['save']))
{
	//start of of varibale and value setting
	$profileid  = $_REQUEST['profileid'];
	$patientid = $_REQUEST['patientid'];
	$age   = $_REQUEST['age'];
	$gender   = $_REQUEST['gender'];
	$height   = $_REQUEST['height'];
  $weight   = $_REQUEST['weight'];
  $ap_hi   = $_REQUEST['ap_hi'];
  $ap_lo   = $_REQUEST['ap_lo'];
  $cholesterol = $_REQUEST['cholesterol'];
  $gluc   = $_REQUEST['gluc'];
  $smoke   = $_REQUEST['smoke'];
  $alcho   = $_REQUEST['alcho'];
  $active   = $_REQUEST['active'];
  $cardio   = $_REQUEST['cardio'];
  

  //end of of varibale and value setting
	//start of typing  query
	$query = "INSERT INTO `dataset`(`profileid`, `patientid`, `age`, `gender`, `height`, `weight`, `ap_hi`, `ap_lo`, `cholesterol`, `gluc`, `smoke`, `alcho`, `active`, `cardio`) VALUES ('$profileid','$patientid','$age','$gender','$height',' $weight',' $ap_hi',' $ap_lo','$cholesterol',' $gluc','$smoke','$alcho','$active','$cardio')";  
	//end of typing the query
  $message=iud_data($query);
  if($message=="sucess"){
		echo"<script>alert('data saved successfully ')</script>";
		echo"<script>window.location='add_data.php'</script>";
	}
  else
  {
		echo"<script>alert('data Not  saved successfully ')</script>";
	}
}
//end of insert operation
//for Update opretion
if(isset($_REQUEST['edit'])){
	$id   = $_REQUEST['id'];
	//start of varibale and value setting
	$profileid  = $_REQUEST['profileid'];
	$patientid = $_REQUEST['patientid'];
	$age   = $_REQUEST['age'];
	$gender   = $_REQUEST['gender'];
	$height   = $_REQUEST['height'];
  $weight   = $_REQUEST['weight'];
  $ap_hi   = $_REQUEST['ap_hi'];
  $ap_lo   = $_REQUEST['ap_lo'];
  $cholesterol = $_REQUEST['cholesterol'];
  $gluc   = $_REQUEST['gluc'];
  $smoke   = $_REQUEST['smoke'];
  $alcho   = $_REQUEST['alcho'];
  $active   = $_REQUEST['active'];
  $cardio   = $_REQUEST['cardio'];
  //end of of varibale and value setting
  //start of typing  query
	$query = "UPDATE `dataset` SET `profileid`='$profileid',`patientid`='$patientid',`age`='$age',`gender`='$gender',`height`='$height',`weight`=' $weight',`ap_hi`='$ap_hi',`ap_lo`='$ap_lo',`cholesterol`='$cholesterol',`gluc`='$gluc',`smoke`='$smoke',`alcho`='$alcho',`active`='$active',`cardio`='$cardio'";  
  
  // end of typing  query
	$message=iud_data($query);
  if($message=="sucess"){
		echo"<script>alert('data saved successfully ')</script>";
		echo"<script>window.location='add_data.php'</script>";
	}else{
		echo"failed ".mysql_error();
	}
}
//for Delete opretion
if($action == 'delete'){
	$id   = $_REQUEST['id'];
	//start of typing  query
	$query = "delete from dataset where id='$id'";  
  //end of typing  query
	$message=iud_data($query);
  if($message=="sucess"){
		echo"<script>alert('data deleted successfully ')</script>";
		echo"<script>window.location='add_data.php'</script>";
	}else{
		echo"<script>alert('failed to delete')</script>";
	}
}

?>

<div class="container">
  
  <?php if($action == 'edit' or $action == 'add' ){ 
          $id = $_REQUEST['id'];
        //start of typing  query
		  $query ="select * from dataset where id='$id'";
      //end of typing  query
      $result = mysqli_query($conn, $query);
          $data = mysqli_fetch_assoc($result)
  ?>
  <form method="post" >
  <!-- start of updataion of the form field and database fields-->
                  
  <table class="table table-striped table-bordered table-hover">
  <tr>
  <td align="right"><b>Profile id</b></td>
  <td>
   <input type="number" name="profileid" id="profileid" class="form-control" value="<?php if($action=="edit"){ echo $data['profileid'];}else {echo "";} ?>" placeholder="Name" required="required" autofocus="autofocus">
  </td>
  </tr>
  <tr>
  <td align="right"><b>Patient id</b></td>
  <td>
  <input type="number" name="patientid" class="form-control" value="<?php if($action=="edit"){echo $data['patientid'];}else{echo "";} ?>"  required="required">
  </td>
  </tr>
  <tr>
  <td align="right"><b> Age<b></td>
  <td>
   <input type="number" name="age" class="form-control" value="<?php if($action=="edit"){ echo $data['age'];} else { echo "";} ?>" required="required">
   </td>
  </tr>
  <tr>
  <td align="right"><b>Gender<b></td>
  <td>
   <input type="text" name="gender" class="form-control" value="<?php if($action=="edit"){ echo $data['gender'];} else { echo "";} ?>"  required="required">
   </td>
  </tr>
  <tr>
  <td align="right"><b>Height<b></td>
  <td>
    <input type="number" name="height" class="form-control" value="<?php if($action=="edit"){ echo $data['height'];} else { echo "";} ?>"  required="required">
   </td>
  </tr>
  <tr>
  <td align="right"><b>Weight<b></td>
  <td>
    <input type="number" name="weight" class="form-control" value="<?php if($action=="edit"){ echo $data['weight'];} else { echo "";} ?>"  required="required">
   </td>
  </tr>
  <tr>
  <td align="right"><b>Ap_hi<b></td>
  <td>
    <input type="number" name="ap_hi" class="form-control" value="<?php if($action=="edit"){ echo $data['ap_hi'];} else { echo "";} ?>"  required="required">
   </td>
  </tr>
  <tr>
  <td align="right"><b>Ap_lo<b></td>
  <td>
    <input type="number" name="ap_lo" class="form-control" value="<?php if($action=="edit"){ echo $data['ap_lo'];} else { echo "";} ?>"  required="required">
   </td>
  </tr>
  <tr>
  <td align="right"><b>Cholesterol<b></td>
  <td>
    <input type="number" name="cholesterol" class="form-control" value="<?php if($action=="edit"){ echo $data['cholesterol'];} else { echo "";} ?>"  required="required">
   </td>
  </tr>
  <tr>
  <td align="right"><b>Glucose<b></td>
  <td>
    <input type="number" name="gluc" class="form-control" value="<?php if($action=="edit"){ echo $data['gluc'];} else { echo "";} ?>"  required="required">
   </td>
  </tr>
  <tr>
  <td align="right"><b>Smoke<b></td>
  <td>
    <input type="number" name="smoke" class="form-control" value="<?php if($action=="edit"){ echo $data['smoke'];} else { echo "";} ?>"  required="required">
   </td>
  </tr>
  <tr>
  <td align="right"><b>Alcohol<b></td>
  <td>
    <input type="number" name="alcho" class="form-control" value="<?php if($action=="edit"){ echo $data['alcho'];} else { echo "";} ?>"  required="required">
   </td>
  </tr>
  <tr>
  <td align="right"><b>Active<b></td>
  <td>
    <input type="number" name="active" class="form-control" value="<?php if($action=="edit"){ echo $data['active'];} else { echo "";} ?>"  required="required">
   </td>
  </tr>
  <tr>
  <td align="right"><b>Cardio<b></td>
  <td>
    <input type="number" name="cardio" class="form-control" value="<?php if($action=="edit"){ echo $data['cardio'];} else { echo "";} ?>"  required="required">
   </td>
  </tr>
  <tr>
  <td colspan="2" align="center">
  <?php
  if($action=="edit")
  {
  ?>
  <button type="submit" class="btn btn-success" name="edit" >Save</button>
  <?php
  }
  else
  {
	?>
    <button type="submit" class="btn btn-success" name="save" >Save</button>
    <?php  
  }
  ?>
  </td>
  </tr>
  </table>
  </form>

  <!-- end of updataion of the form field and database fields-->
  <?php
  ?>
		
  <?php }else{ ?>
		  <center><a href="add_data.php?action=add&id=0" class="btn btn-primary">Insert</a></center>
		  <br />
          <table  id="example2" class="table table-bordered table-hover">
          <tr>
           <td colspan="6" align="right">
            <input type="button" id="btnExport" value="Download As PDF" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
    <script type="text/javascript">
        $("body").on("click", "#btnExport", function () {
            html2canvas($('#example1')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("userdetail.pdf");
                }
            });
        });
    </script>
          </td>
          </tr>
          </table>
		  <table  id="example1" class="table table-bordered table-hover">
			<thead>
			  <tr>
<!-- start of table header change-->
			<th>Profile id</th>
			<th>Patient id</th>
			<th>Age</th>
			<th>Gender</th>
      <th>Height</th>
      <th>Weight</th>
      <th>Ap_hi</th>
      <th>Ap_lo</th>
      <th>Cholesterol</th>
      <th>Glucose</th>
      <th>Smoke</th>
      <th>Alcohol</th>
      <th>Active</th>
      <th>Cardio</th>
			<th>action</th>
      <!-- End of table header change-->
			  </tr>
			</thead>
			<tbody>
			<?php
       //start of typing  query
		$query  = "select * from dataset order by id desc";
    //En of typing  query
$result = mysqli_query($conn,$query);
  while($data = mysqli_fetch_assoc($result))
		{
			?>
			  <tr>
          <!-- start of Changing database variable-->
			  <td><?php echo $data["profileid"]; ?></td>
			<td><?php echo $data["patientid"]; ?></td>
			<td><?php echo $data["age"]; ?></td>
			<td><?php echo $data["gender"]; ?></td>
      <td><?php echo $data["height"]; ?></td>
      <td><?php echo $data["weight"]; ?></td>
      <td><?php echo $data["ap_hi"]; ?></td>
      <td><?php echo $data["ap_lo"]; ?></td>
      <td><?php echo $data["cholesterol"]; ?></td>
      <td><?php echo $data["gluc"]; ?></td>
      <td><?php echo $data["smoke"]; ?></td>
      <td><?php echo $data["alcho"]; ?></td>
      <td><?php echo $data["active"]; ?></td>
      <td><?php echo $data["cardio"]; ?></td>    
			<td>
			<a href="add_data.php?action=edit&id=<?php echo $data["id"]; ?>" class="btn btn-success">Edit</a>
			<a href="add_data.php?action=delete&id=<?php echo $data["id"]; ?>" class="btn btn-danger" onClick="return confirm('are you soure want to delete this')" >Delete</a>
			</td>
      <!-- end of Changing database variable-->
			  </tr>
			  <?php 	
		}
		?>
			</tbody>
		  </table>
  <?php } ?>
  
</div>
<?php
include('footer.php');
?>